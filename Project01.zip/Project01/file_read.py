import sys
'''
Execute way
   from file_read import *
   main('text10.txt')
'''
#####
'''
def read_series(filename):
    try:
        f = open( filename, mode='rt', encoding='utf-8' )
        series = []
        for line in f:
            a = int( line.strip() )
            series.append( a )
    finally:
        f.close()
    return series
'''
'''
#Second way using List Comprehension
def read_series(filename):
    try:
        f = open( filename, mode='rt', encoding='utf-8' )
        return [int(line.strip()) for line in f]
    finally:
        f.close()
'''

#Using with_block - it take care of exception
def read_series(filename):
    with open( filename, mode='rt', encoding='utf-8' ) as f:
        return [int(line.strip()) for line in f]


def main(filename):
    series = read_series( filename )
    print( series )


if __name__ == '__main__':
    main( sys.argv[1] )
'''
Always close the file using file.close after work is done on file
otherwise the data may be lost or computer run out of resources 
use
with_block
  resource cleanup with context-managers


'''