# To Read a txt file from Url

from urllib.request import urlopen

cities = ['mumbai', 'Canada', 'France', 'Paris']
for city in cities:
    print( city )

colors = {'Brown': 0xdc19dc, 'Black': 0xf5ffc, 'White': 0xff0c0}
for color in colors:
    print( color, colors[color] )
with urlopen( "https://www.w3.org/TR/PNG/iso_8859-1.txt" ) as story:
    story_word = []
    for line in story:
        line_words = line.decode( 'utf-8' ).split()
        for word in line_words:
            story_word.append( word )

    print( story_word )
