x = ''' Hello
  I am Parterner
    dlldld
    kdkdkdk
    dkkdkd
    dkkdkdkdk'''
print( x )
y = 'This \n Is \n Multiline \n String'
print( y )
# rAW sTRING
path = r'c:FJFJ/KKF/FKFK/FKKF'
print( path )
print( path.capitalize() )
print( len( path ) )
# Bytes
bt = b'Hello I am Photo In Your App'
print( bt )
bt.split()
print( bt )
dec = 'This Is s'
print( dec.encode( 'utf-8' ) )
data = dec.encode( 'utf-8' )
print( data )
print( data.decode() )

# List
li = ['Hi', 'I', 'hAVE', 5, 'rUPEES']
li.append( '90 Uiie' )
li.remove( 'I' )
print( str( li ) )
print( type( li ) )
# dict - {KEY:VALUES}
