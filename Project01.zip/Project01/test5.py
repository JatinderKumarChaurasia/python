import time

m = ["HELLO", "I", "AM", "IN"]


def addd(k):
    k.append( "AGRA" )
    print( "K VALUE IS:", k )


addd( m )


def banner(message, border='_'):
    line = border * len( message )
    print( message )
    return line


print( banner( "I am OKAY" ) )
print( banner( "I am Default:", '*' ) )
print( time.ctime() )


def show_current(arg=time.ctime()):
    print( arg )


show_current()
# tuple- Immutable Heterogeneous sequence objects
tup = ((23, 45), ('45', '55'), 35)
print( tup[0] )
print( tup[1][1] )
# To create a single element tuple
tup = (45,)
print( type( tup ) )
# Delimiting parentheses are optional for one or more elements
se = 1, 2, 4, 5, 6, 7, 'i'
print( se )
print( type( se ) )


def minmax(items):
    return min( items ), max( items )


mina = ([5, 6, 6, 2, 1, 56, 7, 35, 12])
print( minmax( mina ) )
lower, upper = minmax( mina )
print( "Upper:", upper )
print( "Lower is:", lower )

print( tuple( "Hello" ) )

print( 5 in mina )
print( 56 not in mina )

# String


"""
String is Immutable Heterogeneous object
We can use len to print the len of String
split("sep") to split the string
join to join the string
"""
lis = ["Helo", "I ", "Want ", "To"]
str1 = '-'.join( lis )
str2 = str1.split( '-' )
print( str1 )
print( str2 )

# Partition - return tuple
print( "myselfradheykrishna".partition( 'radhey' ) )
origin, separation, destination = "MaddGuy:Of:345@mail.com".partition( ':' )

print( origin )
print( destination )
# format - to insert values in string
print( "I am {0} years old".format( 32 ) )
post = [1, 3, 5]
print( "My Postition is x={post[0]} ,y={post[1]},z={post[2]}".format( post=post ) )
import math

print( "Values of Math is Pii={m.pi:.3f} Exponential = {m.e}".format( m=math ) )

# Range
range( 5 )
"""
range(10,15) - [10,11,12,13,14]
range(start,stop,step) = range(4,10,2)
"""
# enumerate return (pos,pos[value])
for i in enumerate( lis ):
    print( i )
for i, v in enumerate( lis ):
    print( "I is {} and Value is {}".format( i, v ) )

print( lis[-3] )
print( lis[3:] )
"""
slice[start:] is >=start
slice[:end] is <end
slice[:end]+slice[start:] = slice
"""
y = lis.copy()
print( y == lis )
print( id( y ) == id( lis ) )

"""
count(item) - Count the number of matching of item
index(item) - return the index of first match - return Value Error if not found
del list[index] - delete the item at particular index
remove(item) - delete item by name
in - return true if item is in list
not in - return True if item is not in list
list.copy() --> copy the item references
to make repetition
list*constant - [list,list,..............constant-1]
list.insert(index,item) - insert item at particular index

we can use list1+=list2 or list1.extend(list2) to concatenate

list.reverse() --> to reverse the list
list.sort() --> to sort the list

list.sort(reverse=True) gives descending sort

list.sort(key=len) - sort on the basic of size of index elements

sorted (list)-> built in function sort any iterable series and return a list
reversed(list) -> built in function reverse any iterable series and return reverse iterator
"""

# To print the dictionary in easy to read format
from pprint import pprint as pp

los = {'a': [1, 2, 4], 'b': ['li', 3, 5, 9], 'c': [34, 3.5, 99, 1123], 'd': 34}
pp( los )
