import sys

def main(filename):
    f = open( filename, mode="rt", encoding='UTF-8' )
    for line in f:
        # using file stream
        sys.stdout.write( line )
        # print( line )  # Reading and printing the file
    f.close()


if __name__ == '__main__':
    # main( 'text10.txt' )
    main( sys.argv[1] )
