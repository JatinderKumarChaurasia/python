# Heron of Alexandaria
def sqrt(x):
    '''
     Args:
         x:The Number for Which square root to be computed
     Returns:
          The Square root of x

     '''
    if not isinstance( x, int ):
        raise TypeError( "Arguement must be string" )
    if x < 0:
        raise ValueError( "Cannot compute Square root of Negative Number:{}".format( x ) )
    guess = x
    i = 0
    while guess * guess != x and i < 20:
        guess = (guess + x / guess) / 2.0
        i += 1
    return guess


def main():
    try:
        print( sqrt( 9 ) )
        #  print(sqrt(-1))
        print( sqrt( 4 ) )
        print( sqrt( 8 ) )
        print( sqrt( "3993" ) )
        print( "This is Never Printed." )
    except:
        print( "Cannot compute square root of a negative number" )
        raise
    finally:
        print( "Program Execution continues normally here." )


if __name__ == '__main__':
    main()

'''
#Platform Specific Modules
    Windows     ----    msvcrt
    Linux       ----     sys
                         tty
                        termios
                        '''
