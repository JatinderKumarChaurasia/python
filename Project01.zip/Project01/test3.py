from urllib.request import urlopen

with urlopen( "https://www.w3.org/TR/PNG/iso_8859-1.txt" ) as story:
    story_word = []
    for line in story:
        line_words = line.decode( 'utf-8' ).split()
        for word in line_words:
            story_word.append( word )

    print( story_word )
'''
from urllib.request import urlopen

def fetch_words():
    with urlopen("https://www.w3.org/TR/PNG/iso_8859-1.txt") as story:
        story_word = []
        for line in story:
            line_words = line.decode('utf-8').split()
            for word in line_words:
                story_word.append(word)
        print(story_word)
    for word in story_word:
        print(word)


'''