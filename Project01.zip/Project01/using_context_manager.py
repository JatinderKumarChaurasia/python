from contextlib import closing,contextmanager
class RefrigeratorRaider:
    '''
    Raid a refrigerator

    '''

    def open(self):
        print( "Open Fridge door" )

    def close(self):
        print( "Close Fridge door" )

    def take(self, food):
        print( "Finding .... {}".format( food ) )
        if food == 'deep fried pizza':
            raise RuntimeError( "Health issue may be arise" )
        print( "Taking food :{}".format( food ) )


def raid(food):
    """

    :param food:
    :raise RuntimeError if 'deep fried pizza' is found
    """

#    r = RefrigeratorRaider()
    with closing(RefrigeratorRaider()) as r:
        r.open()
        r.take( food )
      #  r.close()
