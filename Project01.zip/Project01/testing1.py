import unittest
import os

def analyze_text(filename):
    '''Calculate the number of lines and characters in file'''
    '''
    :param filename: The name of file to be analyze
    :raise  IOError - if file does not exists and unable to read
    :returns a tuple where the first element is number of lines in file and second element is the number of characters
    '''
    lines = 0
    char = 0


    with open(filename,'r') as f:
        for line in f:
            lines+=1
            char +=len(line)
        return (lines,char)
      #  return (sum(1 for _ in f))



class TextAnalysisTests(unittest.TestCase):
    '''Text for ``analyze_text()`` function'''

    def setUp(self):
        # fixture creates file for test methods to use
        self.filename = 'text1.txt '
        with open(self.filename,'w') as f:
            f.write("we don't know the taste of success if we don't know the taste of failure")

    def tearDown(self) :
        try:
            os.remove(self.filename)
        except:
            pass

    def test_function_runs(self):
        # BASIC SMOKE TEST
        analyze_text(self.filename)

    def test_line_counts(self):
        '''Check that line count is correct'''
        self.assertEqual(analyze_text(self.filename)[1],72)  # check that if the number of lines is 5

    def test_no_file(self):
        # Check that proper exception is thrown for missing file
        with self.assertRaises(IOError):
            analyze_text("test1.txt")

    def test_no_deletion(self):
        '''Check that function cannot delete the input file'''
        analyze_text(self.filename)
        self.assertTrue(os.path.exists(self.filename))
    if __name__ == '__main__':
       # test_function_runs()
       unittest.main()



'''
First Run

   Ran 1 test in 0.051s

   OK



'''