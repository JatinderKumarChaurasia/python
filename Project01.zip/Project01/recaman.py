from itertools import count,islice
import sys

def sequence():
    # Recaman  Sequence
    seen = set()
    a = 0
    for i in count( 1 ):
        yield a
        seen.add( a )
        c = a - i
        if c < 0 or c in seen:
            c = a + i
        a = c


def write_sequence(filename, num):
    """
    Write Recaman Sequence to text file
    """
    f = open(filename,mode='wt',encoding='UTF-8')
    f.writelines('{0}\n'.format(r) for r in islice(sequence(),num+1))
    f.close()

if __name__ == '__main__':
    write_sequence(filename= sys.argv[1],num=int( sys.argv[2]))