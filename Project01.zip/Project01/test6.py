# Exceptions

'''
Execute Way

from test6 import *
convert(45)

'''
import sys

"""
def convert(s):
    try:
        s = int(s)
        print("Conversion Succeeded :",s)
    except ValueError:
        s=-1
        print("Conversion Unable to Done=",s)
    except TypeError:
        s=-1
        print("Type Error Occured While Conversion of =",s)
    print(s)

"""


# Empty Exception Block used pass which does nothing except take care of empty catch blocks
def convert(s):
    try:
        s = int( s )
        print( "Conversion Succeeded :", s )
    except (ValueError, TypeError) as e:
        s = -1
        print( "Conversion Unable to Done & Conversion Error we got is: {}".format( str( e ) ), file=sys.stderr )
        raise
    print( s )
