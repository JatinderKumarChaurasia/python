import math

def mandel(real, imag):
    '''Compute a point in the mandelbrot

    The Logarithm of number of iterations needed to determine whether a complex point is in the mandelbrot set.
    Args:
        real: The real coordinate
        imag: The imaginary coordinate
    :return
       integer in the range 0 -255
    '''

    x = 0
    y = 0
    for i in range( 1, 257 ):
        if x * x + y * y > 4.0:
            break
        xt = real + x * x - y * y
        y = imag + 2.0 * x * y
        x = xt
    return int( math.log( i ) * 256 / math.log( 255 ) ) - 1


def mandel_brot(size_x, size_y):
    '''Make a mandel brot set image'''
    '''
    :param : size_x -> Image width
    :param : size_y -> Image height
    :return
           A list of integer in the range 0 to 255
    '''
    return [[mandel( (3.5 * x / size_x) - 2.5, (2.08 * y / size_y) - 1.0 ) for x in range( size_x )] for y in
            range( size_y )]
