f = open( "text10.txt", mode="at", encoding="UTF-16", newline="\n" )  # w - write,t-text
f.write("I am Appending the file")
f.writelines(['\n', "Appending at tbe end of file to do append", '\n', 'at the end of file ',
             '\n ','This is always open the file and write in append mode without truncating the file' ])
f.close()
