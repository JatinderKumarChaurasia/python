while True:
    response = input()
    if int( response ) % 4 == 0:
        print( response )
        break
    else:
        continue

