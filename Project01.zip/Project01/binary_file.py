'''
 Binary Files - Device Independent BMP(Bitmap file format)


'''

import mandel_funct
def write_grayscale(filename, pixels):
    ''' Creates and writes grayscale BMP File

    Args:
        filename: The name of BMP file to be created
        pixels :  A rectangular image stored as a sequence of rows
                Each row must be iterable series of integers  in the range 0-255
    Raises:
        OSError: if file could not be written

    '''

    height = len( pixels )
    width = len( pixels[0] )
    with open( filename, mode="wb" ) as bmp:
        # BMP Header
        bmp.write( b'BM' )  # Always do add this as first addition
        size_bookmark = bmp.tell()  # The next four bytes hold the file size as 32-bit Integer
        bmp.write( b'\x00\x00\x00\x00' )  # Little - endian integer .Zero placeholder for now.
        bmp.write( b'\x00\x00' )  # unused 16-digit integer - should be zero
        bmp.write( b'\x00\x00' )  # unused 16-digit integer - should be zero
        pixel_offset_bookmark = bmp.tell()  # the next 4 bit hold the integer offset
        bmp.write( b'\x00\x00\x00\x00' )  # to the pixel data .Zero placeholder for now

        # Image Header
        bmp.write(
            b'\x28\x00\x00\x00' )  # image header size in bytes - 40 decimal - (To convert hexadecimal to number) - 2*16^1 + 8*16^0
        bmp.write( _int32_to_bytes( width ) )  # image width in pixels
        bmp.write( _int32_to_bytes( height ) )  # image height in pixels
        bmp.write( b'\x01\x00' )  # number of Image planes
        bmp.write( b'\x08\x00' )  # bits per pixel 8 for grayscale
        bmp.write( b'\x00\x00\x00\x00' )  # no compression
        bmp.write( b'\x00\x00\x00\x00' )  # zero for uncompressed images
        bmp.write( b'\x00\x00\x00\x00' )  # unused pixel per meter
        bmp.write( b'\x00\x00\x00\x00' )  # unused pixel per meter
        bmp.write( b'\x00\x00\x00\x00' )  # use whole color table
        bmp.write( b'\x00\x00\x00\x00' )  # all colors are important

        # color pallete - a linera grayscale
        for c in range( 256 ):
            bmp.write( bytes( (c, c, c, 0) ) )  # blue,green ,red,zero

        # pixel data
        pixel_data_bookmark = bmp.tell()
        for row in reversed(pixels):
            row_data = bytes(row)
            bmp.write(row_data)
            padding = b'\x00' * (4-(len(row)%4)) #pad row to multiple of four bytes
            bmp.write(padding)

        # End of file
        eof_bookmar = bmp.tell()

        # fulfill promises
        bmp.seek( size_bookmark )
        bmp.write( _int32_to_bytes( eof_bookmar ) )

        bmp.seek( pixel_offset_bookmark )
        bmp.write( _int32_to_bytes( pixel_data_bookmark ) )


def _int32_to_bytes(i):
    #convert int data into four digit
    return bytes( (i & 0xff,
                   i >> 8 & 0xff,
                   i >> 16 & 0xff,
                   i >> 24 & 0xff) )


def bytes_to_integer32(binary_data):
    # convert byte object containing four digit integer to integer
    return binary_data[0]|(binary_data[1]<<8) | (binary_data[2] <<16) | (binary_data[3] << 24)


def dimension(filename):
    '''Determine the dimension in pixels of BMP image.

    :param filename: the name of bmp file
    :returns a tuple containing two integers with width and height in pixels
    :raises ValueError - if the file was not a bmp file
            OSError - if there was a problem reading the file.

    execute:
        import binary_file from *
        dimension('mandel.bmp')

    '''
    with open(filename,mode='rb') as f:
        magic = f.read(2)
        if magic != b'BM':
            raise ValueError("{} is not a bmp file".format(filename))
        f.seek(18)
        width_bytes = f.read(4)
        height_bytes = f.read(4)
        return (bytes_to_integer32(width_bytes),bytes_to_integer32(height_bytes))

def main():
    pixels = mandel_funct.mandel_brot(448,256)
    write_grayscale('mandel.bmp',pixels)
  #  print(pixels)

if __name__ == '__main__':
    main()