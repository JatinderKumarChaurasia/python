words = "In linguistics, a word is the smallest element that can be uttered in isolation with objective or practical meaning. This contrasts deeply with a morpheme, which is the smallest unit of meaning but will not necessarily stand on its own."
words = words.split()
print( words )
# List Comprehension
"""
[expr(item) for item in iterable]
they consists of brackets containing the expression which needs to be executed for each element along with the for loop to iterate over each element
To do f
"""
# list comprehension examples
'''
newCard = [len(word) for word in words]
newCard1 = [(word).partition(',') for word in words]
newCard2 = [(word*len(word)).split() for word in words]
newCard3 = [str(factorial(len(x))) for x in words]
print(newCard1)
print(newCard2)
print("List of String of Factorial of Length of word in Words:",newCard3)
print("List of Length of Word in Words:",newCard)

'''

# Set Comprehension

'''
{expr(item) for item in iterable}
return set

Set not allow duplicate items
'''

'''
setword = {'345','566','12dss',35.5,"ffddf"}
newSet = { str(factorial(len(word))) for word in words}
newSet1 = {len(word) for word in words}
print("Set of Length of Word in Words:",newSet1)
print("Set of String of factorial of Length of Word in words :",newSet)
'''

# Dictionary Comprehension

'''
{key_expr:value_expr for item in iterable}

'''

from pprint import pprint as pp

state_capital = {'Punjab': 'Chandigarh',
                 'Maharashtra': 'Mumbai',
                 'Gujrat': 'Gandhinagar',
                 'Madhya Pradesh': 'Bhopal',
                 'Jharkhand': 'Ranchi',
                 'Uttar Pradesh': 'Lucknow',
                 'Karnataka': 'Bangalore',
                 'Tamilnadu': 'Chennai',
                 'Andhra Pradesh': 'Amaravati',
                 'Telagana': 'Hyderabad',
                 'Kerala': 'Thiruvananthapuram',
                 'Odhisha': 'Bhubaneswar',
                 'West Bengal': 'Kolkata',
                 'Rajasthan': 'Jaipur',
                 'Bihar': 'Patna',
                 'Assam': 'Dispur',
                 'Mizoram': 'Aizawl',
                 'Nagaland': 'Kohima',
                 'Meghalaya': 'Shilong',
                 'Sikkim': 'Gangtok',
                 'Manipur': 'Imphal',
                 'Arunachal Pradesh': 'Itanagar',
                 'Tripura': 'Agartala',
                 'Chattisgarh': 'Raipur or Atal Nagar',
                 'Jammu and Kashmir': 'Kashmir',
                 'Himachal Pradesh': 'Shimla',
                 'Uttrakhand': 'Dehradun',
                 'Haryana': 'Chandigarh',
                 'Goa': 'Panaji'
                 }

stateset = {state: capital for state, capital in state_capital.items()}
# print(pp(stateset))
# os.path.realpath(path) return filepath,os.stat(path).st_size -> return size of file
import os
import glob

file_sizes = {os.path.realpath( p ): os.stat( p ).st_size for p in glob.glob( '*.py' )}
# print(pp(file_sizes))

from math import sqrt


# filtering clause -> [expr(item) for item in iterable if predicate(item)]
def is_prime(x):
    if x < 2:
        return False
    for i in range( 2, int( sqrt( x ) ) + 1 ):
        if x % i == 0:
            return False
        else:
            return True


print( [x for x in range( 101 ) if is_prime( x )] )
prime_square_divisors = {x * x: (1, x, x * x) for x in range( 101 ) if is_prime( x )}
print( pp( prime_square_divisors ) )
