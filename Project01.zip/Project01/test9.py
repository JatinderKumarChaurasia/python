
#iteration Protocals

'''
Iterable Protocol
  Iterable objects can be passed to built-in iter() function to get iterator
  iterator = iter(iterable)
  --------------------------------------------------------------------------
Iterator Protocol
  Iterator Objects can be passed to the built-in next() function to fetch the next item
  item = next(iterator)

'''

print(__doc__)
'''
lis = ['Spain','China','Denmark','England','Netherland','Japan','South Korea','Malaysis','Singapore']
iterator = iter(lis)
for item in next(iterator):
    print(item)
for item in next(iterator):
    print(item)
for item in next(iterator):
    print(item)

def first(iterable):
    iterator = iter(iterable)
    try:
        return next(iterator)
    except StopIteration as e:
        print("Iterator End:")
        raise ValueError("Value Error is Encountered")
first(lis)
first(lis)
first(lis)
print(first(lis))
print(first(lis))
print(first(lis))
print(first(lis))
print(first(lis))
print(first(lis))
print(first(lis))
print(first(lis))
print(first(lis))
first(set())

'''

#Generators
'''
** Specify Iterable Sequences - All generators are iterators
** are Lazily Evaluated - the next value in sequence is computed on demand
** can Model infinite sequence - such as data streams with no definite end
** are composable into pipelines - for natural level processing

Generator are defined by any function that contain yield keyword in definition and also contain return statement with no argument

'''

def yield123():
    yield 1
    yield 3
    yield 2
    return

g = yield123()
print(g) # <generator object yield123 at 0x000001CF487BBDE0>

print(next(g)) #return 1
print(next(g)) #return 3
print(next(g)) #return 2

for v in yield123():
    print(v)

#Stateful Generators
'''
 Maintain state in local variables
 complex control flow
 lazy evaluation
 generators resume execution

'''

def take(count,iterable):
    #First Count the items
    '''
      Take items from the front of iterable

      Args:
         count : The maximum number of items needs to retrieve
         iterable: the source series
      Yields:
          At most 'count' items from 'iterable'

    '''
    counter = 0  # to track how many items yielded so far
    for item in iterable:
        if counter == count:
            return  # break if count number of items are yielded
        counter+=1
        yield item  #At least one yield will be present in function to make it generator


def run_take():
    items = [2,5,6,2,1,69]
    for item in take(3,items):
        print("Items Using Take Generator:{}".format(item))

if __name__ == '__main__':
    run_take()


def distinct(iterable):
    '''
      Return Unique items by eliminating duplicates

    Args:
        iterable: The source series
    Yield:
         Unique Elements in order from 'iterable'
    '''

    seen = set()
    for item in iterable:
        if item in seen:
            continue
        yield item
        seen.add(item)

def run_distinct():
    items = [2,5,1,5,2,5,321,134,5,24,31]
    for item in distinct(items):
        print(item)

if __name__ == '__main__':
    run_distinct()

def run_pipeline():
    items = [2,5,1,5,2,5,321,134,5,24,31]
    for item in take(3,distinct(items)):
        print(item)

if __name__ == '__main__':
    run_pipeline()

'''
   Laziness and Infinite - Just in time Computaion - use for sensor readings and mathematical series and massive files
'''

#Generator Comprehension
'''
Create  a generator object - Lazy and concise evaluation
 (expr(item) for item in iterable)
'''

gener_obj = (x*x for x in range(1,10001))
#print(type(gener_obj))
#print(list(gener_obj))
#print(len(list(gener_obj)))
#print(sum(x*x  for x in range(1,100001)))

from itertools import islice,count
#from test8 import is_prime
#thousand_primes = islice((x for x in count() if is_prime(x)),1000)
#print(list(thousand_primes))
#sumi = sum(islice((x for x in count() if is_prime(x)),1000))
#print(sumi)

print(any([False,True,False,False])) #Return true if any of them is True
print(all([ False,False,True])) # Return True if all of them are either true or false

mon = [1,2,4,5,7,9,0,12,15,19]
tue = [11,13,15,17,21,24,35,16,34]
for item in zip(mon,tue):
    print(item)
for i,j in zip(tue,mon):
    print("Average is:{}".format((i+j)/2))
from itertools import chain
week = chain(mon,tue)
for item in week:
    print (item)
