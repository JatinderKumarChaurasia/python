import pdb

print( pdb.set_trace() )

'''
:returns
      None
      --Return--
      > d:\python\project01\testing2.py(2)<module>()->None
      -> print(pdb.set_trace())
      (Pdb) 

'''
'''
Pdb help


(Pdb) help

Documented commands (type help <topic>):
========================================
EOF    c          d        h         list      q        rv       undisplay
a      cl         debug    help      ll        quit     s        unt      
alias  clear      disable  ignore    longlist  r        source   until    
args   commands   display  interact  n         restart  step     up       
b      condition  down     j         next      return   tbreak   w        
break  cont       enable   jump      p         retval   u        whatis   
bt     continue   exit     l         pp        run      unalias  where    

Miscellaneous help topics:
==========================
exec  pdb

(Pdb)

'''
