import sys
from itertools import count, islice

'''
from recaman_using_with_block import *
write_sequence('text10.txt',25)

'''
def sequence():
    # Recaman  Sequence
    seen = set()
    a = 0
    for i in count( 1 ):
        yield a
        seen.add( a )
        c = a - i
        if c < 0 or c in seen:
            c = a + i
        a = c


def write_sequence(filename, num):
    """
    Write Recaman Sequence to text file
    """
    with open( filename, mode='wt', encoding='UTF-8' ) as f:
        f.writelines( '{0}\n'.format( r ) for r in islice( sequence(), num + 1 ) )


if __name__ == '__main__':
    write_sequence( filename=sys.argv[1], num=int( sys.argv[2] ) )
