#!/usr/bin/env python37
"""
    Retrieves And Print Words from URL
    USAGE:
       python text4.py<URL>
"""

# Execute
'''
from test4 import *
fetch_words("https://www.w3.org/TR/PNG/iso_8859-1.txt")

'''
import sys
from urllib.request import urlopen


def fetch_words(url):
    """ Fetching List of words from URL
     ARGS:
        URL - URL of UTF-8 TEXT DOCUMENT
     RETURNS:
        LIST OF WORDS
    """
    with urlopen( url ) as story:
        story_word = []
        for line in story:
            line_words = line.decode( 'utf-8' ).split()
            for word in line_words:
                story_word.append( word )
    return story_word


def print_items(items):
    """
    Print Items Per Line
      ARGS:
         An iterable series of Printable Items.

    """
    for item in items:
        print( item )


def main(url):
    """Fetch Items From Url and print Items
    ARGS:
       URL - FROM WHICH WORDS ARE FETCHED.
       """
    words = fetch_words( url )
    print_items( words )


if __name__ == '__main__':
    main( sys.argv[1] )  # 0th Argument is the module file name
